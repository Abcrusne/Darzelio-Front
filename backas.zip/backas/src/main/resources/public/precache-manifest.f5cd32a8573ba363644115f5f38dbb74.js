self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e35ef64e96b83ccfef299d92ab7a7de8",
    "url": "/bean-app/index.html"
  },
  {
    "revision": "16572cbe0c1c73df8e5f",
    "url": "/bean-app/static/css/2.437d98bc.chunk.css"
  },
  {
    "revision": "d673404e4671480d27b1",
    "url": "/bean-app/static/css/main.ea53e0f1.chunk.css"
  },
  {
    "revision": "16572cbe0c1c73df8e5f",
    "url": "/bean-app/static/js/2.96ca176e.chunk.js"
  },
  {
    "revision": "3c73c585782ac05880c0f89bcfdbba5a",
    "url": "/bean-app/static/js/2.96ca176e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "04de0c68a2265e356598",
    "url": "/bean-app/static/js/3.621210b6.chunk.js"
  },
  {
    "revision": "d673404e4671480d27b1",
    "url": "/bean-app/static/js/main.90dfb527.chunk.js"
  },
  {
    "revision": "967914473d050434f3ce",
    "url": "/bean-app/static/js/runtime-main.88626820.js"
  }
]);