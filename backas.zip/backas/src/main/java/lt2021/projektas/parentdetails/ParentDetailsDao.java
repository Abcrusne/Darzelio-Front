package lt2021.projektas.parentdetails;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ParentDetailsDao extends JpaRepository<ParentDetails, Long> {
	
	
	
}
