package lt2021.projektas.userRegister;

public enum UserRole {

	PARENT, EDU, ADMIN;

}
