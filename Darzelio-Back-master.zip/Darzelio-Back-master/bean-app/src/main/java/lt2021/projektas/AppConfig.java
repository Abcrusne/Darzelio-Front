
package lt2021.projektas;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@Configuration
@ImportResource({ "classpath*:application-context.xml" })
public class AppConfig {

}